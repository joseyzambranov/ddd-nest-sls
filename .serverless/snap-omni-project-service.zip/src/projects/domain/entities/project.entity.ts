export interface ProjectEntity {
  id: number;
  name: string;
  description: string;
}